# TownyCore
This plugin was designed for handling basic functions inside the Nebula Towny Server (August 2021)

Now repurposed for towny servers in general ;) (As of January 2024)

This version is made for 1.19.4.


Features:
 - Viable Anti-Claimhop and Anti-CombatLog plugin
 - Prevents Anti-Claimhop by keeping a player damageable even if they
   enter claims
 - Prevents the usage of Riptide, Ender Chest access and Elytras in combat
 - Configurable combat timer (30s currently)
 - Prevents the usage of a configurable set of commands (such as teleportation)

Originally made by Ludwig_H for NebulaMC, repurposed and modernized by Foksha, Error110 and Windows10Laptop for more modern towny servers!